<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>找回密码</title>
</head>
<body>
    <form>
        <a href="http://ci.com">年轻人回来吧</a>
        <div >
            <input type="text" id="name" placeholder="用户名"><br/>
            <input type="password" id="password" placeholder="密码"><br/>
            <input type="password" id="password" placeholder="确认密码">
        </div>
        <div>
            <input type="tel" id="password" placeholder="手机号">
            <br/>
            <input type="text"  style="width:82px" id="yzm" placeholder="验证码">
            <button type="submit">获取验证码</button>
        </div>
        <div >
        <button type="submit">下一步</button>
        </div>
    </form>
</body>
</html>