
    <div class="col-lg-8 col-md-6 col-lg-offset-2 col-md-offset-1"> 
        <h2 align="center">留言板</h2>
        <h3>这里写留言，记住了</h3>
		<div align="center">
            <ul  class="pagination">
                <li><a href="#">&laquo;</a></li>
	            <li class="active"><a href="#">1</a></li>
	            <li class="disabled"><a href="#">2</a></li>
	            <li><a href="#">3</a></li>
	            <li><a href="#">4</a></li>
	            <li><a href="#">5</a></li>
	            <li><a href="#">&raquo;</a></li>
            </ul>
        </div>
    </div>
