<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>恋人APP</title>
    <style type="text/css">
		.reply_btn{
			border:none;
			background:none;
			color:#337ab7;
		}
		.reply_btn:hover{
			border:none;
			cursor: pointer;
			text-decoration: underline;
			color: #ba1a09;
		}
	</style>
</head>
<body>
<div class="container">
		<h3 align="center">留言板</h3>
		<div class="col-lg-8 col-md-6 col-lg-offset-2 col-md-offset-1">
			<form action="action.php?a=message" method="post">
				<textarea name="message_content" cols="80" rows="10" class="form-control" placeholder="你想说些什么..." required></textarea><br /><br />
				<input type="submit" value="留言" class="btn btn-success">
				<input type="reset" value="取消" class="btn btn-default">
			</form>
		</div>
	</div>

    
</body>
</html>