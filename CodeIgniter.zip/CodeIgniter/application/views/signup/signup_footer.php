<!-- <a href="index.php/Hello/test" class="text">立刻登录</a>
                        <a href="index.php/Hello/nopwd" class="text">忘记密码>></a> -->
            </div>
        </div>
    </div>
</body>

</html>