<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {
    public function index()
    {
        $this->load->helper('form');
        $this->load->view('signup/signup_head');
        $this->load->view('signup/signup_form');
        $this->load->view('signup/signup_footer');
    }
  public function signup_up()
    {
          $this->load->helper('url');
          if ($this->input->post('username'))
          {
                $this->load->model('signup_model','',TRUE);
                $this->signup_model->add_signup();
                // $this->load->view('signup/signup_form');
                $this->load->view('signup/signup_ok');
                // redirect('signup/signup_ok','refresh');
          }
          else
          {
            echo'求你输入账号';
          }
    }

}
